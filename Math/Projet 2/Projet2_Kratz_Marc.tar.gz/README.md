﻿Langage de programmation utilisé : Python3

Commande à exécuter dans le terminal :

Pour windows:
python exo.py 5 2 10000

Ou pour Linux:
python3 exo.py 5 2 10000
